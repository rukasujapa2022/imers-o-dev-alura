valorDeWons = prompt("Dgite um valor em wons!")
umWon = 0.0040
alert("R$" + valorDeWons * umWon)