Para rodar o jogo, abra a pasta Dist e execute index.html

To run the game, open the Dist folder and execute index.html
